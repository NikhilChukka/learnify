# learnify
This is an interactive tool that helps students learn by summarizing content, identifying key points, generating flashcards, and conducting a knowledge test through multiple-choice questions.
